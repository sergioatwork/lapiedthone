# Swagger\Client\RunnerCtrlApi

All URIs are relative to *http://localhost:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**createRunner**](RunnerCtrlApi.md#createrunner) | **POST** /runner/create | 
[**deleteRunner**](RunnerCtrlApi.md#deleterunner) | **DELETE** /runner/delete/{idUser}/{idRun} | 
[**readAllRun**](RunnerCtrlApi.md#readallrun) | **GET** /runner/readAllRun/{idUser} | 
[**readAllRunner**](RunnerCtrlApi.md#readallrunner) | **GET** /runner/read | 
[**readAllUser1**](RunnerCtrlApi.md#readalluser1) | **GET** /runner/readAllUser/{idRun} | 
[**readRunner**](RunnerCtrlApi.md#readrunner) | **GET** /runner/read/{idUser}/{idRun} | 
[**updateRunner**](RunnerCtrlApi.md#updaterunner) | **PUT** /runner/update | 

# **createRunner**
> bool createRunner($body)



### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\RunnerCtrlApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$body = new \Swagger\Client\Model\Runner(); // \Swagger\Client\Model\Runner | 

try {
    $result = $apiInstance->createRunner($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling RunnerCtrlApi->createRunner: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\Runner**](../Model/Runner.md)|  |

### Return type

**bool**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **deleteRunner**
> bool deleteRunner($id_user, $id_run)



### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\RunnerCtrlApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$id_user = 56; // int | 
$id_run = 56; // int | 

try {
    $result = $apiInstance->deleteRunner($id_user, $id_run);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling RunnerCtrlApi->deleteRunner: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id_user** | **int**|  |
 **id_run** | **int**|  |

### Return type

**bool**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **readAllRun**
> \Swagger\Client\Model\Runner[] readAllRun($id_user)



### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\RunnerCtrlApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$id_user = 56; // int | 

try {
    $result = $apiInstance->readAllRun($id_user);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling RunnerCtrlApi->readAllRun: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id_user** | **int**|  |

### Return type

[**\Swagger\Client\Model\Runner[]**](../Model/Runner.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **readAllRunner**
> \Swagger\Client\Model\Runner[] readAllRunner()



### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\RunnerCtrlApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);

try {
    $result = $apiInstance->readAllRunner();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling RunnerCtrlApi->readAllRunner: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\Runner[]**](../Model/Runner.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **readAllUser1**
> \Swagger\Client\Model\Runner[] readAllUser1($id_run)



### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\RunnerCtrlApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$id_run = 56; // int | 

try {
    $result = $apiInstance->readAllUser1($id_run);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling RunnerCtrlApi->readAllUser1: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id_run** | **int**|  |

### Return type

[**\Swagger\Client\Model\Runner[]**](../Model/Runner.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **readRunner**
> \Swagger\Client\Model\Runner readRunner($id_user, $id_run)



### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\RunnerCtrlApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$id_user = 56; // int | 
$id_run = 56; // int | 

try {
    $result = $apiInstance->readRunner($id_user, $id_run);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling RunnerCtrlApi->readRunner: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id_user** | **int**|  |
 **id_run** | **int**|  |

### Return type

[**\Swagger\Client\Model\Runner**](../Model/Runner.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **updateRunner**
> bool updateRunner($body)



### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\RunnerCtrlApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$body = new \Swagger\Client\Model\Runner(); // \Swagger\Client\Model\Runner | 

try {
    $result = $apiInstance->updateRunner($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling RunnerCtrlApi->updateRunner: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\Runner**](../Model/Runner.md)|  |

### Return type

**bool**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

