# Runner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id_user** | **int** |  | [optional] 
**id_run** | **int** |  | [optional] 
**contribution** | **int** |  | [optional] 
**km** | **int** |  | [optional] 
**start_date** | [**\DateTime**](\DateTime.md) |  | [optional] 
**end_date** | [**\DateTime**](\DateTime.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

