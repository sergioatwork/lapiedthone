# User

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional] 
**name** | **string** |  | [optional] 
**first_name** | **string** |  | [optional] 
**email** | **string** |  | [optional] 
**password** | **string** |  | [optional] 
**enable** | **bool** |  | [optional] 
**admin** | **bool** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

