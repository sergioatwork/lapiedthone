package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Album
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-01-31T13:11:57.874Z[GMT]")


public class Album   {
  @JsonProperty("id")
  private Integer id = null;

  @JsonProperty("note")
  private String note = null;

  @JsonProperty("idUser")
  private Integer idUser = null;

  @JsonProperty("idRun")
  private Integer idRun = null;

  public Album id(Integer id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
   **/
  @Schema(description = "")
  
    public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Album note(String note) {
    this.note = note;
    return this;
  }

  /**
   * Get note
   * @return note
   **/
  @Schema(description = "")
  
    public String getNote() {
    return note;
  }

  public void setNote(String note) {
    this.note = note;
  }

  public Album idUser(Integer idUser) {
    this.idUser = idUser;
    return this;
  }

  /**
   * Get idUser
   * @return idUser
   **/
  @Schema(description = "")
  
    public Integer getIdUser() {
    return idUser;
  }

  public void setIdUser(Integer idUser) {
    this.idUser = idUser;
  }

  public Album idRun(Integer idRun) {
    this.idRun = idRun;
    return this;
  }

  /**
   * Get idRun
   * @return idRun
   **/
  @Schema(description = "")
  
    public Integer getIdRun() {
    return idRun;
  }

  public void setIdRun(Integer idRun) {
    this.idRun = idRun;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Album album = (Album) o;
    return Objects.equals(this.id, album.id) &&
        Objects.equals(this.note, album.note) &&
        Objects.equals(this.idUser, album.idUser) &&
        Objects.equals(this.idRun, album.idRun);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, note, idUser, idRun);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Album {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    note: ").append(toIndentedString(note)).append("\n");
    sb.append("    idUser: ").append(toIndentedString(idUser)).append("\n");
    sb.append("    idRun: ").append(toIndentedString(idRun)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
