package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Article
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-01-31T13:11:57.874Z[GMT]")


public class Article   {
  @JsonProperty("id")
  private Integer id = null;

  @JsonProperty("title")
  private String title = null;

  @JsonProperty("note")
  private String note = null;

  @JsonProperty("idPhoto")
  private Integer idPhoto = null;

  @JsonProperty("startDate")
  private OffsetDateTime startDate = null;

  @JsonProperty("endDate")
  private OffsetDateTime endDate = null;

  @JsonProperty("news")
  private Boolean news = null;

  @JsonProperty("idUser")
  private Integer idUser = null;

  @JsonProperty("idRun")
  private Integer idRun = null;

  public Article id(Integer id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
   **/
  @Schema(description = "")
  
    public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Article title(String title) {
    this.title = title;
    return this;
  }

  /**
   * Get title
   * @return title
   **/
  @Schema(description = "")
  
    public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public Article note(String note) {
    this.note = note;
    return this;
  }

  /**
   * Get note
   * @return note
   **/
  @Schema(description = "")
  
    public String getNote() {
    return note;
  }

  public void setNote(String note) {
    this.note = note;
  }

  public Article idPhoto(Integer idPhoto) {
    this.idPhoto = idPhoto;
    return this;
  }

  /**
   * Get idPhoto
   * @return idPhoto
   **/
  @Schema(description = "")
  
    public Integer getIdPhoto() {
    return idPhoto;
  }

  public void setIdPhoto(Integer idPhoto) {
    this.idPhoto = idPhoto;
  }

  public Article startDate(OffsetDateTime startDate) {
    this.startDate = startDate;
    return this;
  }

  /**
   * Get startDate
   * @return startDate
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getStartDate() {
    return startDate;
  }

  public void setStartDate(OffsetDateTime startDate) {
    this.startDate = startDate;
  }

  public Article endDate(OffsetDateTime endDate) {
    this.endDate = endDate;
    return this;
  }

  /**
   * Get endDate
   * @return endDate
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getEndDate() {
    return endDate;
  }

  public void setEndDate(OffsetDateTime endDate) {
    this.endDate = endDate;
  }

  public Article news(Boolean news) {
    this.news = news;
    return this;
  }

  /**
   * Get news
   * @return news
   **/
  @Schema(description = "")
  
    public Boolean isNews() {
    return news;
  }

  public void setNews(Boolean news) {
    this.news = news;
  }

  public Article idUser(Integer idUser) {
    this.idUser = idUser;
    return this;
  }

  /**
   * Get idUser
   * @return idUser
   **/
  @Schema(description = "")
  
    public Integer getIdUser() {
    return idUser;
  }

  public void setIdUser(Integer idUser) {
    this.idUser = idUser;
  }

  public Article idRun(Integer idRun) {
    this.idRun = idRun;
    return this;
  }

  /**
   * Get idRun
   * @return idRun
   **/
  @Schema(description = "")
  
    public Integer getIdRun() {
    return idRun;
  }

  public void setIdRun(Integer idRun) {
    this.idRun = idRun;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Article article = (Article) o;
    return Objects.equals(this.id, article.id) &&
        Objects.equals(this.title, article.title) &&
        Objects.equals(this.note, article.note) &&
        Objects.equals(this.idPhoto, article.idPhoto) &&
        Objects.equals(this.startDate, article.startDate) &&
        Objects.equals(this.endDate, article.endDate) &&
        Objects.equals(this.news, article.news) &&
        Objects.equals(this.idUser, article.idUser) &&
        Objects.equals(this.idRun, article.idRun);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, title, note, idPhoto, startDate, endDate, news, idUser, idRun);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Article {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    title: ").append(toIndentedString(title)).append("\n");
    sb.append("    note: ").append(toIndentedString(note)).append("\n");
    sb.append("    idPhoto: ").append(toIndentedString(idPhoto)).append("\n");
    sb.append("    startDate: ").append(toIndentedString(startDate)).append("\n");
    sb.append("    endDate: ").append(toIndentedString(endDate)).append("\n");
    sb.append("    news: ").append(toIndentedString(news)).append("\n");
    sb.append("    idUser: ").append(toIndentedString(idUser)).append("\n");
    sb.append("    idRun: ").append(toIndentedString(idRun)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
