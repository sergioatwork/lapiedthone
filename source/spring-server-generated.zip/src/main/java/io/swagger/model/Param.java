package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Param
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-01-31T13:11:57.874Z[GMT]")


public class Param   {
  @JsonProperty("id")
  private Integer id = null;

  @JsonProperty("paramKey")
  private String paramKey = null;

  @JsonProperty("paramValue")
  private String paramValue = null;

  public Param id(Integer id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
   **/
  @Schema(description = "")
  
    public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Param paramKey(String paramKey) {
    this.paramKey = paramKey;
    return this;
  }

  /**
   * Get paramKey
   * @return paramKey
   **/
  @Schema(description = "")
  
    public String getParamKey() {
    return paramKey;
  }

  public void setParamKey(String paramKey) {
    this.paramKey = paramKey;
  }

  public Param paramValue(String paramValue) {
    this.paramValue = paramValue;
    return this;
  }

  /**
   * Get paramValue
   * @return paramValue
   **/
  @Schema(description = "")
  
    public String getParamValue() {
    return paramValue;
  }

  public void setParamValue(String paramValue) {
    this.paramValue = paramValue;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Param param = (Param) o;
    return Objects.equals(this.id, param.id) &&
        Objects.equals(this.paramKey, param.paramKey) &&
        Objects.equals(this.paramValue, param.paramValue);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, paramKey, paramValue);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Param {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    paramKey: ").append(toIndentedString(paramKey)).append("\n");
    sb.append("    paramValue: ").append(toIndentedString(paramValue)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
