package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Photo
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-01-31T13:11:57.874Z[GMT]")


public class Photo   {
  @JsonProperty("id")
  private Integer id = null;

  @JsonProperty("note")
  private String note = null;

  @JsonProperty("file")
  private String file = null;

  @JsonProperty("idAlbum")
  private Integer idAlbum = null;

  public Photo id(Integer id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
   **/
  @Schema(description = "")
  
    public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Photo note(String note) {
    this.note = note;
    return this;
  }

  /**
   * Get note
   * @return note
   **/
  @Schema(description = "")
  
    public String getNote() {
    return note;
  }

  public void setNote(String note) {
    this.note = note;
  }

  public Photo file(String file) {
    this.file = file;
    return this;
  }

  /**
   * Get file
   * @return file
   **/
  @Schema(description = "")
  
    public String getFile() {
    return file;
  }

  public void setFile(String file) {
    this.file = file;
  }

  public Photo idAlbum(Integer idAlbum) {
    this.idAlbum = idAlbum;
    return this;
  }

  /**
   * Get idAlbum
   * @return idAlbum
   **/
  @Schema(description = "")
  
    public Integer getIdAlbum() {
    return idAlbum;
  }

  public void setIdAlbum(Integer idAlbum) {
    this.idAlbum = idAlbum;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Photo photo = (Photo) o;
    return Objects.equals(this.id, photo.id) &&
        Objects.equals(this.note, photo.note) &&
        Objects.equals(this.file, photo.file) &&
        Objects.equals(this.idAlbum, photo.idAlbum);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, note, file, idAlbum);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Photo {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    note: ").append(toIndentedString(note)).append("\n");
    sb.append("    file: ").append(toIndentedString(file)).append("\n");
    sb.append("    idAlbum: ").append(toIndentedString(idAlbum)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
