package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Runner
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-01-31T13:11:57.874Z[GMT]")


public class Runner   {
  @JsonProperty("idUser")
  private Integer idUser = null;

  @JsonProperty("idRun")
  private Integer idRun = null;

  @JsonProperty("contribution")
  private Integer contribution = null;

  @JsonProperty("km")
  private Integer km = null;

  @JsonProperty("startDate")
  private OffsetDateTime startDate = null;

  @JsonProperty("endDate")
  private OffsetDateTime endDate = null;

  public Runner idUser(Integer idUser) {
    this.idUser = idUser;
    return this;
  }

  /**
   * Get idUser
   * @return idUser
   **/
  @Schema(description = "")
  
    public Integer getIdUser() {
    return idUser;
  }

  public void setIdUser(Integer idUser) {
    this.idUser = idUser;
  }

  public Runner idRun(Integer idRun) {
    this.idRun = idRun;
    return this;
  }

  /**
   * Get idRun
   * @return idRun
   **/
  @Schema(description = "")
  
    public Integer getIdRun() {
    return idRun;
  }

  public void setIdRun(Integer idRun) {
    this.idRun = idRun;
  }

  public Runner contribution(Integer contribution) {
    this.contribution = contribution;
    return this;
  }

  /**
   * Get contribution
   * @return contribution
   **/
  @Schema(description = "")
  
    public Integer getContribution() {
    return contribution;
  }

  public void setContribution(Integer contribution) {
    this.contribution = contribution;
  }

  public Runner km(Integer km) {
    this.km = km;
    return this;
  }

  /**
   * Get km
   * @return km
   **/
  @Schema(description = "")
  
    public Integer getKm() {
    return km;
  }

  public void setKm(Integer km) {
    this.km = km;
  }

  public Runner startDate(OffsetDateTime startDate) {
    this.startDate = startDate;
    return this;
  }

  /**
   * Get startDate
   * @return startDate
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getStartDate() {
    return startDate;
  }

  public void setStartDate(OffsetDateTime startDate) {
    this.startDate = startDate;
  }

  public Runner endDate(OffsetDateTime endDate) {
    this.endDate = endDate;
    return this;
  }

  /**
   * Get endDate
   * @return endDate
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getEndDate() {
    return endDate;
  }

  public void setEndDate(OffsetDateTime endDate) {
    this.endDate = endDate;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Runner runner = (Runner) o;
    return Objects.equals(this.idUser, runner.idUser) &&
        Objects.equals(this.idRun, runner.idRun) &&
        Objects.equals(this.contribution, runner.contribution) &&
        Objects.equals(this.km, runner.km) &&
        Objects.equals(this.startDate, runner.startDate) &&
        Objects.equals(this.endDate, runner.endDate);
  }

  @Override
  public int hashCode() {
    return Objects.hash(idUser, idRun, contribution, km, startDate, endDate);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Runner {\n");
    
    sb.append("    idUser: ").append(toIndentedString(idUser)).append("\n");
    sb.append("    idRun: ").append(toIndentedString(idRun)).append("\n");
    sb.append("    contribution: ").append(toIndentedString(contribution)).append("\n");
    sb.append("    km: ").append(toIndentedString(km)).append("\n");
    sb.append("    startDate: ").append(toIndentedString(startDate)).append("\n");
    sb.append("    endDate: ").append(toIndentedString(endDate)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
